# Travel App 

## Project Seven - Travel App (Front End Developer Udacity Nanodegree)
#### What I used: HTML, CSS, Javascript (Vanilla)

Run Commands:
To install packages 
npm install

To build dev
npm run build-dev

To build prod
npm run build-prod

To run
npm start

TO perform jest test
npm run test

Hope you find this helpful!!!!!!




copyright - Raghu Sharma
