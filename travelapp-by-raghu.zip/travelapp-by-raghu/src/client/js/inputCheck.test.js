import { checkInput } from './inputCheck.js';

describe('RegExp: input', function () {
  it('should be a  valid string', function () {
    const urlRGEX = /^[a-zA-Z\s]{0,255}$/;
    const city1 = 'Jammu';
    expect(urlRGEX.test(city1)).toBe(true);
  });
  });
  describe('RegExp: input', function () {
  it('should be a  invalid string', function () {
    const urlRGEX = /^[a-zA-Z\s]{0,255}$/;
    const city1 = 'Jammu';
    const city2 = 'JAm0u';
    expect(urlRGEX.test(city2)).toBe(false);
    });
});
